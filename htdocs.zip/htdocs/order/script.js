let thing
var input = document.getElementById("id");
let response
let loop = 1

thing = new XMLHttpRequest();

input.addEventListener("keydown", function (e) {
    if (e.code === "Enter") {  //checks whether the pressed key is "Enter"
		send();
    }
});

thing.addEventListener("load", () => {
	response = thing.responseText.replace(/['"]+/g, '')

	if(loop == 1){
		product = document.getElementById("product").value
        id = document.getElementById("id").value
		thing.open("put", "https://cookies2x2-default-rtdb.firebaseio.com/orders.json");
		thing.send('"' + response + product + ':' + id + ', "')
		loop = 0
	}
    document.getElementById("product").value = ""
})

function send(){
	thing.open("get", "https://cookies2x2-default-rtdb.firebaseio.com/orders.json");
	thing.send()
	if(loop == 0){
		loop = 1
	}
}
